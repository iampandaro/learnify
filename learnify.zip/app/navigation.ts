import {  } from "next-intl/navigation"

import { localePrefix, locales, pathnames } from "./config"

export const {} = createNavigation({
	locales,
	pathnames,
	localePrefix
})